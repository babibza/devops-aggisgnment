# K8sFleetmanWebappAngular

This is an experimental project to port the front end to Angular.

It's temporarily on hold, as some very minor problems got in the way. For example, the Moving Marker that we rely on doesn't have any native integration with Angular and it would take us too long to unpick how to do it. 

For now, we'll stick with SpringBoot (MVC) on the front end.
